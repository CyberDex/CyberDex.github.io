export const gitHubURL = 'https://github.com/CyberDex/fire-wheel';
export const startBalance = 1000;