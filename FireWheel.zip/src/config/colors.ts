export const colors = {
    bg: 0x000000,
    text: 0xFFFFFF,
    disabledStroke: 0x474747,
}