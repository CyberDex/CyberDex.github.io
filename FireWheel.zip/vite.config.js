export default { 
    base: '/fire-wheel/'
}